# Play the game locally

The downloadable ZIP contains ordinary HTML, CSS, JavaScript, and image files.
Players do not need Vite, TypeScript, the source repository, or an internet
connection after downloading it.

## Reliable method

1. Download and extract `hello-world-game-local.zip`.
2. Open a terminal in the extracted folder.
3. Start any small static web server. For example, with Python:

   ```bash
   python3 -m http.server 8000
   ```

4. Visit http://localhost:8000/ in a browser.
5. Stop the server with `Ctrl+C` when finished.

## Why use a local server?

Opening `index.html` directly may be blocked by browser security rules for
JavaScript modules and local files. A local server only delivers the packaged
files to the browser; it does not send the game or saved progress to the
internet.

Game progress remains in that browser's local storage.
